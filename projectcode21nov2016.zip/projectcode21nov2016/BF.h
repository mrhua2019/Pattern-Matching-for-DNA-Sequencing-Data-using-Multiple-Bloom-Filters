
#include "bloom_filter.hpp"
#include "Search.h"

#include <vector>


extern std::vector <std::string> Table;

extern int MapSize;

extern bloom_filter filter[258];
extern int MBF_Construction_time;

int bloomfilter(std::vector<size_t >*,int);
