/*
 **************************************************************************
 *                                                                        *
 *                           Open Bloom Filter                            *
 *                                                                        *
 * Description: Basic Bloom Filter Usage                                  *
 * Author: Arash Partow - 2000                                            *
 * URL: http://www.partow.net                                             *
 * URL: http://www.partow.net/programming/hashfunctions/index.html        *
 *                                                                        *
 * Copyright notice:                                                      *
 * Free use of the Bloom Filter Library is permitted under the guidelines *
 * and in accordance with the most current version of the Common Public   *
 * License.                                                               *
 * http://www.opensource.org/licenses/cpl1.0.php                          *
 *                                                                        *
 **************************************************************************
*/



/*
   Description: This example demonstrates basic usage of the Bloom filter.
                Initially some values are inserted then they are subsequently
                queried, noting any false positives or errors.
*/


#include <iostream>
#include <string>
#include <map>
#include <vector>
#include "bloom_filter.hpp"
#include "BF.h"
#include <chrono>
bloom_filter filter[258];
//bloom_filter filter[4098];
//bloom_filter filter[1026];

using namespace std;

using namespace std::chrono;
int bloomfilter(std::vector<size_t >* vv,int BFCounter)
{

MBF_Construction_time=MBF_Construction_time+1;
high_resolution_clock::time_point t1 = high_resolution_clock::now(); 
   bloom_parameters parameters;

   // How many elements roughly do we expect to insert?
   parameters.projected_element_count = (vv->size());

   // Maximum tolerable false positive probability? (0,1)
   parameters.false_positive_probability =0.01; //  (1 in 100)

   // Simple randomizer (optional)
  // parameters.random_seed = 0xA5A5A5A5;

   if (!parameters)
   {
      std::cout << "Error - Invalid set of bloom filter parameters!" << std::endl;
      return 1;
   }

   parameters.compute_optimal_parameters();

   //Instantiate Bloom Filter
   filter[BFCounter]=parameters;


//////////////////////////////
std::vector<size_t >::iterator it;

 	for (it=vv->begin(); it<vv->end(); it++)
   	{

  filter[BFCounter].insert(*it);
//std::cout  << typeof(*it) << endl;

}



 
//std::cout  << "Yahoo: " << BFCounter;
//std::cout  << " " << MapSize-1<< std::endl;


    high_resolution_clock::time_point t2 = high_resolution_clock::now();
int duration = duration_cast<microseconds>( t2 - t1 ).count();
MBF_Construction_time=MBF_Construction_time+duration;
	

if(BFCounter== MapSize-1)
{
	cout << "Duration " << MBF_Construction_time << " microseconds" << endl;
long int MBFSize=0;
for(int i=0;i<MapSize-1;i++)
{
	//cout << "FilterSize   " << filter[i].size() << " bits" << endl;
	 MBFSize= MBFSize + filter[i].size();
}

	cout << "MBF Size" << MBFSize << " bits" << endl;
Search();
}
/////////////////////////////
  


        

   return 0;
}
