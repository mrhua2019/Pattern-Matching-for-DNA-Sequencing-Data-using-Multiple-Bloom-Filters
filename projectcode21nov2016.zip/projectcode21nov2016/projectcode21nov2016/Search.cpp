#include <iostream>
#include <string>
#include <map>
#include <vector>
#include "bloom_filter.hpp"
#include "Search.h"
#include "BF.h"
#include <fstream>
#include <sstream>
#include <algorithm>
#include "leveldb/db.h"
#include <chrono>

using namespace std;
using namespace std::chrono;


void Search()
{

  leveldb::DB* db;
    leveldb::Options options;
    options.create_if_missing = true;

    leveldb::Status status = leveldb::DB::Open(options, "./newdb/chr2", &db);

    if (false == status.ok())
    {
        cerr << "Unable to open/create test database './newdb/chr2" << endl;
        cerr << status.ToString() << endl;
        //return -1;
    }

////////// Storing pattern Kmers in VECTOR:kmers  /////////////////////////
high_resolution_clock::time_point t1 = high_resolution_clock::now(); 
    ifstream is("File.txt"); 
    char c;
    string buf;string kmer;
    vector<string> kmers;
    unsigned int kmermax=6;
    unsigned  int kmermin=6;
    while (is.good()) {
	is.get(c);
	if (is.good()) {
	    if ((unsigned  int) buf.size() == kmermax) {
		buf = buf.substr(1);
	    }
	    buf.append(1, c);
	    for (unsigned int i = kmermin; i <= (unsigned ) buf.size(); ++i) {
		 kmer = buf.substr(buf.size() - i, i);
		kmers.push_back(kmer);

	    }
	}
    }	
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


////////// 1. Storing Bloom Filter index of each corresponding pattern kmer in VECTOR: BF_Index//////////////////////
////////// 2. Storing Bloom Filter sizes of each corresponding pattern kmer in VECTOR: BF_Size//////////////////////
    vector<unsigned int> BF_Index;
    vector<string>::iterator it;
    vector<string>::iterator it2;
	vector<unsigned int> BF_Size;

	for (it=kmers.begin(); it<kmers.end(); it++)
   	{ 
		//cout  << *it << endl;

  		it2=find(Table.begin(),Table.end(),*it);

		auto pos = distance(Table.begin(), it2);

		if(it2!=Table.end())
        	{
			//cout<<"FOUND  "<< *it  <<"  at position: " <<pos<<endl;
			BF_Index.push_back(pos);          
  BF_Size.push_back(filter[pos].size());
			//cout<<"FOUND  "<< filter[pos].size() <<endl;
		}
  	}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


////////// Finding Kmer with minimum location data in KV-Store//////////////////////

	
unsigned int KmerIndex_Min = distance(BF_Size.begin(),min_element(BF_Size.begin(),BF_Size.end()));
  	//cout << "The distance is: " << min_pos << "|value is "<<*min_element(BF_Size.begin(),BF_Size.end())<<endl;
 	//cout<< "nm " << BF_Size.at(min_pos) << endl;
 
	// int =min_pos;  // it states the location with index starting from 0 && KmerIndex_Min is the position of the kmer in pattern with minimum location data

			//cout<<"mIN  "<< KmerIndex_Min <<endl;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


////////// Extracting data from KV-Store//////////////////////
  

	string KV_kmer= Table.at(BF_Index.at( KmerIndex_Min));
	//cout << "Kmer : " << KV_kmer << endl;
  	
	string value2;
      	status = db->Get(leveldb::ReadOptions(), KV_kmer, &value2);
	//cout << "Key:Values " << value2 << endl;
     
 
//////////////////////////////////////////////////////////////////////////////////////////


///////////////////////////Putting values from KV-Store to Int Vector: numbers////////////////////////////////////////////////////


stringstream ss(value2);

vector<unsigned int> numbers((istream_iterator<unsigned int>(ss)), 
                    istream_iterator<unsigned int>());


/*std::vector<int>::iterator it6;

	for (it6=numbers.begin(); it6<numbers.end(); it6++)
   	{ 
             cout << *it6 << endl;
	}
*/
//////////////////////////////////Bloom Filters Searcing for patterns/////////////////////////////////////////////


unsigned int Pos= BF_Index.size()-(KmerIndex_Min+1); //+1
unsigned int Neg=BF_Index.size()-(Pos+1); //-1

vector<unsigned int>::iterator it6;
vector<unsigned int>::iterator it7;
vector<unsigned int> copy_numbers;
unsigned int temp=1; 		
vector<unsigned int>::iterator position ;		 
//cout << "Pos " << Pos << endl; 	
//cout << "Neg " << Neg << endl;
copy_numbers=numbers;


	for (it7=BF_Index.begin(); Neg>0 ; ++it7)
   	{ 

		//cout << "BF_index " << *it7 << endl;
		
		

			for (it6=copy_numbers.begin(); it6<copy_numbers.end(); ++it6)
   			{ 
				size_t  i =*it6-Neg; 		
				if (filter[*it7].contains(i)==0)
         			{
	   	
					//numbers.erase (copy_numbers.begin()-(it6 - copy_numbers.begin()-1));
            				 position = std::find(numbers.begin(), numbers.end(), *it6);
					if (position != numbers.end()) // == myVector.end() means the element was not found
   					numbers.erase(position);
                                }
             			
			}

			copy_numbers=numbers;
			--Neg;
		
		
	}
++it7;
                
		
		for (it7=it7; it7< BF_Index.end(); ++it7)
   	{ 

			
				//cout << "temp " << temp << endl;

				for (it6=copy_numbers.begin(); it6<copy_numbers.end(); ++it6)
   			       { 
 					 size_t i =*it6+temp;
             				if (filter[*it7].contains(i)==0)
					{      //   cout << "y3o " << *it6+temp  << endl;
						position = find(numbers.begin(), numbers.end(), *it6);
						if (position != numbers.end()) // == myVector.end() means the element was not found
   						numbers.erase(position);
					}
				}
					copy_numbers=numbers;
					++temp;
			

			
		
	}

/*
int count=0;
	for (it6=copy_numbers.begin(); it6<copy_numbers.end(); it6++)
   	{ count=count+1;
          cout << "Location " << *it6-Neg-1 << endl;
	} */
      cout << "Pattern present " << copy_numbers.size() << endl;
   high_resolution_clock::time_point t2 = high_resolution_clock::now();
	auto duration = duration_cast<microseconds>( t2 - t1 ).count();
	cout << "Duration" << duration << "microseconds" << endl;

   delete db;
}
