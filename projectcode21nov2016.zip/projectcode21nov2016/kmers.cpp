#include <iostream>
#include <map>
#include <cmath>
#include <stdlib.h>
#include <vector>
#include <sstream>
#include <string>
#include "leveldb/db.h"
#include "bloom_filter.hpp"
#include "BF.h"
#include <chrono>
using namespace std::chrono;
using namespace std;

int MBF_Construction_time; 
int MapSize;
vector<string> Table;
int main (int argc, char** argv) {

MBF_Construction_time=0;
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
 leveldb::DB* db;
    leveldb::Options options;
    options.create_if_missing = true;

    leveldb::Status status = leveldb::DB::Open(options, "./newdb/chr2", &db);

    if (false == status.ok())
    {
        cerr << "Unable to open/create test database './newdb/chr2" << endl;
        cerr << status.ToString() << endl;
        return -1;
    }
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//    

    if (argc != 3) {
	cerr << "usage: " << argv[0] << " [kmermin] [kmermax]" << endl
	     << "Generate kmer frequency statistics for all kmers in stdin between" << endl
	     << "kmermin and kmermax size." << endl;
	return 1;
    }

    int kmermin = atoi(argv[1]);
    int kmermax = atoi(argv[2]);

    char c;
    string buf;
    unsigned long location=0;

    long long totalchrs = 0;
    map<string,vector<size_t > > kmers;

    	string kmer ;
    while (cin.good()) {
	cin.get(c);
 
	if (cin.good()) {
	    ++totalchrs;
	    if ((int) buf.size() == kmermax) {
		buf = buf.substr(1);
	    }
	    buf.append(1, c);   
	    for (int i = kmermin; i <= (int) buf.size(); ++i) { 
		location=location+1;
		//cout << buf << " Location : " << location << endl;
		 kmer = buf.substr(buf.size() - i, i);
		kmers[kmer].push_back(location);

	    }
	}
    }
if(kmers[kmer].size()==1)
{kmers.erase (kmer);  }

 MapSize=kmers.size();
//+++++++++++++++++++++++++++++++++++++++++++++++++++//
  leveldb::WriteOptions writeOptions;
 int BFCounter=0;
    std::vector<size_t >::iterator it;
     for (map<string, vector<size_t >  >::iterator k = kmers.begin(); k != kmers.end(); ++k)
   {


		ostringstream keyStream;
		ostringstream valueStream;

		const string& kmer = k->first;
		keyStream << kmer ;
		if(kmer.find_first_of("N")!=std::string::npos){ cout << kmer << endl;}
else{
    		for (it=kmers[kmer].begin(); it<kmers[kmer].end(); it++)
   	        {
			valueStream  << *it << '\t';
                      
        
		}

Table.push_back(kmer);
	
bloomfilter(&kmers[kmer],BFCounter);
BFCounter++;
   db->Put(writeOptions, keyStream.str(), valueStream.str());
}
    }

//++++++++++++++;+++++++++++++++++++++++++++++++++++++//


//Code to extract data from Key Value store//

   /*     high_resolution_clock::time_point t1 = high_resolution_clock::now(); 
	string value2;
      	status = db->Get(leveldb::ReadOptions(), "TGAACT", &value2);
	cout << "Key:Values " << value2 << endl;
        high_resolution_clock::time_point t2 = high_resolution_clock::now();
	auto duration = duration_cast<microseconds>( t2 - t1 ).count();
	cout << duration;

  */
    
    // Close the database
 // delete db;
    
    return 0;

}
